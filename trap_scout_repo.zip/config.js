window.TRAP_SCOUT_CONFIG = {
  SUPABASE_URL: 'https://rbkaospswxatykrfjyrh.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJia2Fvc3Bzd3hhdHlrcmZqeXJoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTYyMjgyMjAsImV4cCI6MjA3MTgwNDIyMH0.qLi2bK02fP-JTAey_dLi-lN_j3L7HSFatKp-n2w-I1g',
  DEFAULT_CENTER: [-33.95, 21.03],
  DEFAULT_ZOOM: 16
};